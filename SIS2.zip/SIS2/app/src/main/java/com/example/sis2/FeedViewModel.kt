package com.example.sis2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class FeedViewModel : ViewModel() {

    // приватная изменяемая LiveData
    private val _posts = MutableLiveData<List<Post>>()
    // публичная только для чтения
    val posts: LiveData<List<Post>> get() = _posts

    init {
        // картинки
        _posts.value = listOf(
            Post(
                id = 1,
                text = "Первая новость — тестовый пост",
                imageUrl = "https://picsum.photos/400/200?random=1"
            ),
            Post(
                id = 2,
                text = "Вторая новость — картинка с random url",
                imageUrl = "https://picsum.photos/400/200?random=2"
            ),
            Post(
                id = 3,
                text = "Третья новость — для RecyclerView",
                imageUrl = "https://picsum.photos/400/200?random=3"
            ),
            Post(
                id = 3,
                text = "Третья новость — для RecyclerView",
                imageUrl = "https://picsum.photos/400/200?random=4"
            )
        )
    }

    fun toggleLike(postId: Int) {
        val current = _posts.value?.toMutableList() ?: return
        val i = current.indexOfFirst { it.id == postId }
        if (i != -1) {
            val p = current[i]
            current[i] = p.copy(isLiked = !p.isLiked)
            _posts.value = current
        }
    }
}
