package com.example.sis2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load



class PostsAdapter(
    private var items: List<Post>,
    private val onLikeClick: (Post) -> Unit
) : RecyclerView.Adapter<PostsAdapter.PostViewHolder>() {

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgPost: ImageView = view.findViewById(R.id.imgPost)
        val txtPost: TextView = view.findViewById(R.id.txtPostText)
        val btnLike: ImageView = view.findViewById(R.id.btnLike)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val item = items[position]

        holder.txtPost.text = item.text

        // картинки
        holder.imgPost.load(item.imageUrl)

        holder.btnLike.setImageResource(
            if (item.isLiked) android.R.drawable.btn_star_big_on
            else android.R.drawable.btn_star_big_off
        )

        holder.btnLike.setOnClickListener {
            onLikeClick(item)
        }
    }

    override fun getItemCount() = items.size

    fun submitList(newList: List<Post>) {
        items = newList
        notifyDataSetChanged()
    }
}
